import pyodbc
from util.db_property_util import DBPropertyUtil
from exception.custom_exceptions import DatabaseConnectionException
class DBConnUtil:
    @staticmethod
    def getDBConnection():
        try:
            # This method now gets the connection string from DBPropertyUtil
            conn_str = DBPropertyUtil.getConnectionString()
            return pyodbc.connect(conn_str)
        except Exception as e:
            # It's good to raise a custom exception here for better error handling in the service layer
            raise DatabaseConnectionException(f"Failed to connect to DB: {e}") from e

    @staticmethod
    def close_db_connection(conn):
        if conn:
            conn.close()

# Note: This file assumes DBPropertyUtil is in the same 'util' package
# and DatabaseConnectionException is defined in your 'exception' package.