# In util/db_property_util.py

class DBPropertyUtil:
    @staticmethod
    def getConnectionString(_ignored_filename=None):
        try:
            # Connection details for Windows Authentication
            # No 'uid' or 'pwd' needed in the props dictionary for Windows Authentication
            props = {
                'driver': 'ODBC Driver 17 for SQL Server',
                'server': 'LAPTOP-LIKITA', # <-- Verify your server name is correct
                'database': 'HMBank',      # <-- Verify your database name is correct
                # No 'uid' or 'pwd' keys here for Windows Authentication
            }

            # Build the connection string for Windows Authentication
            # Use Trusted_Connection=yes instead of UID and PWD
            conn_str = (
                f"DRIVER={{{props['driver']}}};"
                f"SERVER={props['server']};"
                f"DATABASE={props['database']};"
                f"Trusted_Connection=yes;" # <-- Indicates Windows Authentication
            )
            return conn_str

        except KeyError as e:
             # Catching KeyError specifically to give a more relevant message
             raise Exception(f"Missing key in DB properties dictionary: {e}") from e
        except Exception as e:
            # Catching other potential errors during string building
            raise Exception(f"Error building DB connection string: {e}") from e