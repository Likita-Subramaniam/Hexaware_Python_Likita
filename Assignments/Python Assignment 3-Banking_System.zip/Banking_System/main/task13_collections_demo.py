# task13_collections_demo.py (or add these functions to main_module.py)

# Assuming necessary imports are available (from main_module.py or if this is a separate file)
from dao.bank_repository_impl import BankRepositoryImpl # If this is a separate file
from entity.account import Account
from entity.customer import Customer # Needed for accessing customer details
from exception.custom_exceptions import DatabaseOperationException, DatabaseConnectionException, BankingException

# You will need an instance of your BankServiceProviderImpl to call repository methods
# from dao.bank_service_provider_impl import BankServiceProviderImpl

def demonstrate_list_accounts(bank_service):
    """
    Demonstrates fetching all accounts and using a Python list.
    """
    print("\n--- Demonstrating Task 13: Using List (All Accounts) ---")
    try:
        # Use the service layer to get all accounts (service layer uses the repository)
        accounts_list = bank_service.list_accounts()

        if accounts_list:
            print(" ✅  Accounts fetched and stored in a List:")
            # Iterate through the list
            for i, account in enumerate(accounts_list):
                print(f"  {i+1}. {account}") # Assumes Account.__str__() is informative

            # Demonstrate basic list operations
            print(f"\nTotal number of accounts (List size): {len(accounts_list)}")

            # Accessing elements by index
            if len(accounts_list) >= 1:
                print(f"First account in the list: {accounts_list[0]}")
            if len(accounts_list) >= 2:
                print(f"Second account in the list: {accounts_list[1]}")

            # Slicing the list
            if len(accounts_list) > 3:
                 print(f"First three accounts (List slice): {accounts_list[:3]}")

            # Check if an account object is in the list (requires __eq__ method in Account)
            # Example: Find an account by number and check if it's in the list
            # try:
            #     acc_to_find_no = int(input("\nEnter an account number to check if it's in the list: "))
            #     # You would need to fetch this specific account from the DB or find it in the list
            #     # For demonstration, let's just create a dummy object with the number
            #     # Note: This check relies on __eq__ comparing account numbers
            #     dummy_account = Account(0, None) # Create a dummy Account object
            #     dummy_account.acc_no = acc_to_find_no
            #     if dummy_account in accounts_list:
            #          print(f"Account {acc_to_find_no} is found in the list.")
            #     else:
            #          print(f"Account {acc_to_find_no} is NOT found in the list.")
            # except ValueError:
            #      print("Invalid input.")

        else:
            print(" ℹ️  No accounts found in the database to demonstrate list.")

    except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f" ❌  An error occurred while fetching accounts: {e}")
    except Exception as e:
        print(f" ❌  An unexpected error occurred: {e}")


def demonstrate_set_unique_cities(bank_service):
    """
    Demonstrates fetching accounts and using a Python set to find unique customer cities.
    """
    print("\n--- Demonstrating Task 13: Using Set (Unique Customer Cities) ---")
    try:
        # Use the service layer to get all accounts
        accounts_list = bank_service.list_accounts()

        if accounts_list:
            # Create a set to store unique cities
            unique_cities = set()

            # Iterate through the list of accounts and add customer cities to the set
            for account in accounts_list:
                # Assuming Customer object is available via account.customer and has an 'address' attribute
                if account.customer and account.customer.address:
                     # Extract city from the address. This is a simple example,
                     # you might need more robust parsing depending on address format.
                     # Assuming the last part of the address is the city.
                     city = account.customer.address.split(',')[-1].strip()
                     unique_cities.add(city)
                elif account.customer:
                     print(f" ⚠ ️ Customer for account {account.acc_no} has no address.")


            if unique_cities:
                print(" ✅  Unique Customer Cities (using a Set):")
                # Iterate through the set (order is not guaranteed)
                for city in unique_cities:
                    print(f"  - {city}")

                print(f"\nTotal number of unique cities (Set size): {len(unique_cities)}")

                # Check if a specific city is in the set
                # city_to_check = input("\nEnter a city name to check if it's in the set: ").strip()
                # if city_to_check in unique_cities:
                #      print(f"'{city_to_check}' is in the set of unique cities.")
                # else:
                #      print(f"'{city_to_check}' is NOT in the set of unique cities.")

            else:
                 print(" ℹ️  No customer addresses found to determine unique cities.")


        else:
            print(" ℹ️  No accounts found in the database to demonstrate set.")

    except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f" ❌  An error occurred while fetching accounts: {e}")
    except Exception as e:
        print(f" ❌  An unexpected error occurred: {e}")


def demonstrate_dictionary_account_balances(bank_service):
    """
    Demonstrates fetching accounts and using a Python dictionary to map account numbers to balances.
    """
    print("\n--- Demonstrating Task 13: Using Dictionary (Account Balances) ---")
    try:
        # Use the service layer to get all accounts
        accounts_list = bank_service.list_accounts()

        if accounts_list:
            # Create a dictionary to map account numbers to balances
            account_balances_dict = {}

            # Populate the dictionary
            for account in accounts_list:
                account_balances_dict[account.acc_no] = account.balance

            if account_balances_dict:
                print(" ✅  Account Balances (using a Dictionary):")
                # Iterate through the dictionary
                for acc_no, balance in account_balances_dict.items():
                    print(f"  Account {acc_no}: {balance:.2f}")

                print(f"\nTotal number of accounts in dictionary: {len(account_balances_dict)}")

                # Accessing a value by key (account number)
                # try:
                #     acc_no_to_check = int(input("\nEnter an account number to get its balance from the dictionary: "))
                #     if acc_no_to_check in account_balances_dict:
                #         print(f"Balance for account {acc_no_to_check}: {account_balances_dict[acc_no_to_check]:.2f}")
                #     else:
                #         print(f"Account {acc_no_to_check} not found in the dictionary.")
                # except ValueError:
                #     print("Invalid input.")


            else:
                 print(" ℹ️  No accounts found to populate the dictionary.")


        else:
            print(" ℹ️  No accounts found in the database to demonstrate dictionary.")

    except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f" ❌  An error occurred while fetching accounts: {e}")
    except Exception as e:
        print(f" ❌  An unexpected error occurred: {e}")


def demonstrate_sorting_accounts(bank_service):
    """
    Demonstrates fetching accounts and sorting them using Python's list sort method.
    """
    print("\n--- Demonstrating Task 13: Sorting Accounts ---")
    try:
        # Use the service layer to get all accounts
        accounts_list = bank_service.list_accounts()

        if accounts_list:
            print("Original order:")
            for account in accounts_list:
                print(f"  {account.acc_no}: {account.balance:.2f} ({account.customer.first_name} {account.customer.last_name})")

            # --- Sorting by Balance ---
            # Sort the list in-place by balance
            accounts_list.sort(key=lambda account: account.balance)
            print("\nSorted by Balance (Ascending):")
            for account in accounts_list:
                 print(f"  {account.acc_no}: {account.balance:.2f} ({account.customer.first_name} {account.customer.last_name})")

            # Sort by balance descending
            accounts_list.sort(key=lambda account: account.balance, reverse=True)
            print("\nSorted by Balance (Descending):")
            for account in accounts_list:
                 print(f"  {account.acc_no}: {account.balance:.2f} ({account.customer.first_name} {account.customer.last_name})")

            # --- Sorting by Customer Last Name, then First Name ---
            # Sort using a lambda function that returns a tuple (last_name, first_name)
            accounts_list.sort(key=lambda account: (account.customer.last_name, account.customer.first_name))
            print("\nSorted by Customer Name (Last, First):")
            for account in accounts_list:
                 print(f"  {account.customer.last_name}, {account.customer.first_name} (Acc No: {account.acc_no})")

            # You can define more complex sorting criteria as needed.

        else:
            print(" ℹ️  No accounts found in the database to demonstrate sorting.")

    except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f" ❌  An error occurred while fetching accounts: {e}")
    except Exception as e:
        print(f" ❌  An unexpected error occurred: {e}")


# Example of how to integrate these into main_module.py
# You would add these options to your main menu loop

# In your main_module.py, inside the while loop:
# ... (existing menu options) ...
# print("11. Demonstrate List (All Accounts)")
# print("12. Demonstrate Set (Unique Cities)")
# print("13. Demonstrate Dictionary (Account Balances)")
# print("14. Demonstrate Sorting Accounts")
# print("15. Exit") # Adjust exit number

# Inside the if/elif block for handling choice:
# ... (existing choice handling) ...
# elif choice == "11":
#     demonstrate_list_accounts(bank_service) # Pass the bank_service instance
# elif choice == "12":
#     demonstrate_set_unique_cities(bank_service)
# elif choice == "13":
#     demonstrate_dictionary_account_balances(bank_service)
# elif choice == "14":
#      demonstrate_sorting_accounts(bank_service)
# elif choice == "15": # Adjust exit number
#     print(" 👋  Thank you for banking with us!")
#     break
# ... (rest of exception handling) ...
