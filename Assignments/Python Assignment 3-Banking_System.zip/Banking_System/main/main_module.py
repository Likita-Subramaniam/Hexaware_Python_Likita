# main_module.py
from dao.bank_service_provider_impl import BankServiceProviderImpl
from entity.customer import Customer
from entity.account import Account
from entity.transaction import Transaction
from exception.custom_exceptions import (
    InsufficientFundException,
    InvalidAccountException,
    OverDraftLimitExcededException,
    DatabaseOperationException,
    DatabaseConnectionException,
    BankingException
)
from util.db_conn_util import DBConnUtil
from util.db_property_util import DBPropertyUtil
import sys
from datetime import datetime

# --- Task 13 Collection Demonstration Functions (Keeping the functions but they won't be called from the main menu) ---
def demonstrate_list_accounts(bank_service):
     """
    Demonstrates fetching all accounts and using a Python list.
    """
     print("\n--- Demonstrating Task 13: Using List (All Accounts) ---")
     try:
        accounts_list: list[Account] = bank_service.list_accounts()
        if accounts_list:
            print("    Accounts fetched and stored in a List:")
            for i, account in enumerate(accounts_list):
                print(f"  {i+1}. {account}")
            print(f"\nTotal number of accounts (List size): {len(accounts_list)}")
            if len(accounts_list) >= 1:
                print(f"First account in the list: {accounts_list[0]}")
            if len(accounts_list) >= 2:
                print(f"Second account in the list: {accounts_list[1]}")
            if len(accounts_list) > 3:
                print(f"First three accounts (List slice): {accounts_list[:3]}")
        else:
            print("  ℹ ️  No accounts found in the database to demonstrate list.")
     except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f"     An error occurred while fetching accounts: {e}")
     except Exception as e:
        print(f"    An unexpected error occurred: {e}")

def demonstrate_set_unique_cities(bank_service):
     """
    Demonstrates fetching accounts and using a Python set to find unique customer cities.
    """
     print("\n--- Demonstrating Task 13: Using Set (Unique Customer Cities) ---")
     try:
        accounts_list: list[Account] = bank_service.list_accounts()
        if accounts_list:
            unique_cities = set()
            for account in accounts_list:
                if account.customer and account.customer.address:
                     address_parts = account.customer.address.split(',')
                     if address_parts:
                         city = address_parts[-1].strip()
                         unique_cities.add(city)
                     else:
                         print(f"   ️ Customer for account {account.acc_no} has empty address string.")
                elif account.customer:
                     print(f"   ️ Customer for account {account.acc_no} has no address.")

            if unique_cities:
                print("     Unique Customer Cities (using a Set):")
                for city in unique_cities:
                    print(f"  - {city}")
                print(f"\nTotal number of unique cities (Set size): {len(unique_cities)}")
            else:
                 print("  ℹ ️  No customer addresses found to determine unique cities.")
        else:
            print("  ℹ ️  No accounts found in the database to demonstrate set.")
     except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f"     An error occurred while fetching accounts: {e}")
     except Exception as e:
        print(f"    An unexpected error occurred: {e}")

def demonstrate_dictionary_account_balances(bank_service):
     """
    Demonstrates fetching accounts and using a Python dictionary to map account numbers to balances.
    """
     print("\n--- Demonstrating Task 13: Using Dictionary (Account Balances) ---")
     try:
        accounts_list: list[Account] = bank_service.list_accounts()
        if accounts_list:
            account_balances_dict = {}
            for account in accounts_list:
                account_balances_dict[account.acc_no] = account.balance

            if account_balances_dict:
                print("   Account Balances (using a Dictionary):")
                for acc_no, balance in account_balances_dict.items():
                    print(f"  Account {acc_no}: {balance:.2f}")
                print(f"\nTotal number of accounts in dictionary: {len(account_balances_dict)}")
            else:
                 print("  ℹ ️  No accounts found to populate the dictionary.")
        else:
            print("  ℹ ️  No accounts found in the database to demonstrate dictionary.")
     except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f"     An error occurred while fetching accounts: {e}")
     except Exception as e:
        print(f"     An unexpected error occurred: {e}")

def demonstrate_sorting_accounts(bank_service):
     """
    Demonstrates fetching accounts and sorting them using Python's list sort method.
    """
     print("\n--- Demonstrating Task 13: Sorting Accounts ---")
     try:
        accounts_list: list[Account] = bank_service.list_accounts()
        if accounts_list:
            print("Original order:")
            for account in accounts_list:
                customer_name = "N/A"
                if account.customer:
                    customer_name = f"{account.customer.first_name} {account.customer.last_name}"
                print(f"  Acc No: {account.acc_no}, Balance: {account.balance:.2f}, Customer: {customer_name}")

            accounts_list_by_balance = sorted(accounts_list, key=lambda account: account.balance)
            print("\nSorted by Balance (Ascending):")
            for account in accounts_list_by_balance:
                 customer_name = "N/A"
                 if account.customer:
                     customer_name = f"{account.customer.first_name} {account.customer.last_name}"
                 print(f"  Acc No: {account.acc_no}, Balance: {account.balance:.2f}, Customer: {customer_name}")

            accounts_list_by_balance_desc = sorted(accounts_list, key=lambda account: account.balance, reverse=True)
            print("\nSorted by Balance (Descending):")
            for account in accounts_list_by_balance_desc:
                 customer_name = "N/A"
                 if account.customer:
                     customer_name = f"{account.customer.first_name} {account.customer.last_name}"
                 print(f"  Acc No: {account.acc_no}, Balance: {account.balance:.2f}, Customer: {customer_name}")

            accounts_list_by_name = sorted(accounts_list, key=lambda account: (
                account.customer.last_name if account.customer and account.customer.last_name else '',
                account.customer.first_name if account.customer and account.customer.first_name else ''
            ))
            print("\nSorted by Customer Name (Last, First):")
            for account in accounts_list_by_name:
                 customer_name = "N/A"
                 if account.customer:
                     customer_name = f"{account.customer.first_name} {account.customer.last_name}"
                 print(f"  Customer: {customer_name} (Acc No: {account.acc_no})")

        else:
            print("  ℹ ️  No accounts found in the database to demonstrate sorting.")
     except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
        print(f"     An error occurred while fetching accounts: {e}")
     except Exception as e:
        print(f"    An unexpected error occurred: {e}")


# --- Main Application Module ---
def main():
     """
    Main function to run the menu-driven banking application.
    """
     bank_service = None
     try:
        # Use updated DB connection logic without db.properties file
        conn_str = DBPropertyUtil.getConnectionString()
        conn = DBConnUtil.getDBConnection()  # updated
        bank_service = BankServiceProviderImpl()
     except DatabaseConnectionException as e:
        print(f"     Application startup failed: {e}")
        sys.exit(1)

     while True:
        print("\n     ----- Welcome to HMBank -----")
        print("1. Create Account")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Calculate Interest (for Savings Accounts)")
        print("5. Get Balance")
        print("6. Get Account Details")
        print("7. Transfer Funds")
        print("8. List All Accounts")
        print("9. Get Transactions for Account")
        print("10. Exit") # Changed exit to 10
        choice = input("     Enter your choice: ")

        try: # Use a single try block for core banking operations
            if choice == "1":
                print("\n--- Create Account ---")
                first = input("Enter First Name: ")
                last = input("Enter Last Name: ")
                email = input("Enter Email: ")
                phone = input("Enter Phone (10 digits): ")
                address = input("Enter Address: ")

                # Basic validation for customer details before creating object
                try:
                    # Note: If customer_id is auto-generated by the DB,
                    # you might not set it here, or set to 0 and let the repo handle it.
                    # If you need to create the customer first to get an ID,
                    # the service layer would need a method for that, and you'd call it here.
                    customer = Customer(0, first, last, email, phone, address) # Use 0 as placeholder if DB auto-generates
                except ValueError as e:
                    print(f"     Error validating customer details: {e}")
                    continue # Skip to next menu iteration


                print("Select Account Type:")
                print("  S - Savings")
                print("  C - Current")
                print("  Z - Zero Balance")

                acc_type_choice = input("Enter account type (S/C/Z): ").upper()
                acc_type = ""
                if acc_type_choice == "S":
                    acc_type = "Savings"
                elif acc_type_choice == "C":
                    acc_type = "Current"
                elif acc_type_choice == "Z":
                    acc_type = "ZeroBalance"
                else:
                    print("    Invalid account type selected.")
                    continue # Go back to main menu

                balance = 0.0
                # Get initial balance for Savings/Current, ZeroBalance starts at 0
                if acc_type in ["Savings", "Current"]:
                    while True:
                        try:
                            balance_input = input(f"Enter Initial Balance for {acc_type} Account: ")
                            if not balance_input: # Handle empty input
                                print("    Initial balance cannot be empty.")
                                continue
                            balance = float(balance_input)
                            # Minimum balance check for Savings (can also be in service/repo)
                            if acc_type == "Savings" and balance < 500:
                                print("    ️ Savings account requires a minimum initial balance of 500.")
                                continue
                            break # Exit balance input loop if valid
                        except ValueError:
                            print("   Invalid amount entered. Please enter a number.")

                # Call the service provider to create the account, which uses the repository
                account_number = bank_service.create_account(customer, acc_type, balance)
                print(f"\n    Account created successfully! Account No: {account_number}")

            elif choice == "2":
                print("\n--- Deposit ---")
                acc_no_input = input("Enter Account Number: ")
                amount_input = input("Enter Deposit Amount: ")
                try:
                    acc_no = int(acc_no_input)
                    amount = float(amount_input)
                    new_balance = bank_service.deposit(acc_no, amount)
                    print(f"     Deposit successful. New balance for account {acc_no}: {new_balance:.2f}")
                except ValueError:
                    print("     Invalid input. Please enter numbers for account number and amount.")

            elif choice == "3":
                print("\n--- Withdraw ---")
                acc_no_input = input("Enter Account Number: ")
                amount_input = input("Enter Withdrawal Amount: ")
                try:
                    acc_no = int(acc_no_input)
                    amount = float(amount_input)
                    new_balance = bank_service.withdraw(acc_no, amount)
                    print(f"     Withdrawal successful. New balance for account {acc_no}: {new_balance:.2f}")
                except ValueError:
                    print("     Invalid input. Please enter numbers for account number and amount.")

            elif choice == "4":
                print("\n--- Calculate Interest ---")
                # This method calculates interest for ALL savings accounts in the DB via the repository
                bank_service.calculate_interest()
                print("   Interest calculation process completed for Savings Accounts.")

            elif choice == "5":
                print("\n--- Get Balance ---")
                acc_no_input = input("Enter Account Number: ")
                try:
                    acc_no = int(acc_no_input)
                    balance = bank_service.get_account_balance(acc_no)
                    print(f"   Current Balance for Account {acc_no}: {balance:.2f}")
                except ValueError:
                    print("     Invalid input. Please enter a number for account number.")

            elif choice == "6":
                print("\n--- Get Account Details ---")
                acc_no_input = input("Enter Account Number: ")
                try:
                    acc_no = int(acc_no_input)
                    account_details = bank_service.get_account_details(acc_no)
                    print("     Account Details:")
                    print(account_details) # Assumes Account.__str__ method provides good formatting
                except ValueError:
                    print("     Invalid input. Please enter a number for account number.")

            elif choice == "7":
                print("\n--- Transfer Funds ---")
                from_acc_no_input = input("Enter Source Account Number: ")
                to_acc_no_input = input("Enter Destination Account Number: ")
                amount_input = input("Enter Transfer Amount: ")
                try:
                    from_acc_no = int(from_acc_no_input)
                    to_acc_no = int(to_acc_no_input)
                    amount = float(amount_input)
                    bank_service.transfer(from_acc_no, to_acc_no, amount)
                    print(f"    Transfer of {amount:.2f} from account {from_acc_no} to account {to_acc_no} successful.")
                    # Optional: Display new balances after transfer
                    # print(f"New balance for {from_acc_no}: {bank_service.get_account_balance(from_acc_no):.2f}")
                    # print(f"New balance for {to_acc_no}: {bank_service.get_account_balance(to_acc_no):.2f}")
                except ValueError:
                    print("     Invalid input. Please enter numbers for account numbers and amount.")

            elif choice == "8":
                print("\n--- List All Accounts ---")
                accounts = bank_service.list_accounts()
                if accounts:
                    print("    All Accounts:")
                    for acc in accounts:
                        print(acc) # Assumes Account.__str__ is informative
                else:
                    print("  ℹ ️  No accounts found.")

            elif choice == "9":
                print("\n--- Get Transactions for Account ---")
                acc_no_input = input("Enter Account Number: ")
                from_date_input = input("Enter Start Date (YYYY-MM-DD): ")
                to_date_input = input("Enter End Date (YYYY-MM-DD): ")
                try:
                    acc_no = int(acc_no_input)
                    # You might want to add date format validation here
                    transactions = bank_service.get_transactions_for_account(acc_no, from_date_input, to_date_input)
                    if transactions:
                        print(f"     Transactions for Account {acc_no} between {from_date_input} and {to_date_input}:")
                        for tx in transactions:
                            print(tx) # Assumes Transaction.__str__ is informative
                    else:
                         print(f"  ℹ ️  No transactions found for account {acc_no} in the specified date range.")
                except ValueError:
                    print("    Invalid input. Please enter a number for account number and dates in YYYY-MM-DD format.")
                except Exception as e: # Catch other potential errors from service/repo
                    print(f"     An error occurred while fetching transactions: {e}")

            elif choice == "10": # Exit option
                print("    Thank you for banking with us!")
                break # Exit the loop

            else:
                print("    Invalid choice. Please try again.")

        # --- Exception Handling ---
        # Catch specific custom banking exceptions first
        except InsufficientFundException as e:
            print(f"    Transaction failed: {e.message}")
        except InvalidAccountException as e:
            print(f"    Operation failed: {e.message}")
        except OverDraftLimitExcededException as e:
            print(f"   Withdrawal failed: {e.message}")
        except DatabaseOperationException as e:
             print(f"     Database error during operation: {e}")
        except DatabaseConnectionException as e:
            # This should ideally be caught on startup, but added here as a fallback
             print(f"    Database connection error: {e}")
        except BankingException as e:
            # Catch any other custom banking exceptions
            print(f"    A banking error occurred: {e.message}")
        except Exception as e:
            # Catch any unexpected errors
            print(f"    An unexpected error occurred: {e}")
            # Optional: print traceback for debugging
            # import traceback
            # traceback.print_exc()

if __name__ == "__main__":
    main()