from entity.account import SavingsAccount, CurrentAccount
from entity.customer import Customer

class Bank:
    def __init__(self):
        self.accounts = {}  # Dictionary to store acc_no: Account
        self.last_acc_no = 1000

    def generate_account_number(self):
        self.last_acc_no += 1
        return self.last_acc_no

    def create_account(self, acc_type, first, last, email, phone, address, balance):
        customer_id = self.generate_account_number()
        acc_no = self.generate_account_number()
        cust_name = f"{first} {last}"

        try:
            customer = Customer(customer_id, first, last, email, phone, address)
        except ValueError as e:
            print(f"Error creating customer: {e}")
            return None

        if acc_type.lower() == "savings":
            account = SavingsAccount(acc_no, cust_name, balance, customer)
        elif acc_type.lower() == "current":
            account = CurrentAccount(acc_no, cust_name, balance, customer)
        else:
            print("Invalid account type!")
            return None

        self.accounts[acc_no] = account
        print(f"\n✅ Account created successfully! Account No: {acc_no}")
        return acc_no

    def deposit(self, acc_no, amount):
        account = self.accounts.get(acc_no)
        if account:
            account.deposit(amount)
        else:
            print("⚠️ Account not found!")

    def withdraw(self, acc_no, amount):
        account = self.accounts.get(acc_no)
        if account:
            account.withdraw(amount)
        else:
            print("⚠️ Account not found!")

    def calculate_interest(self, acc_no):
        account = self.accounts.get(acc_no)
        if account:
            account.calculate_interest()
        else:
            print("⚠️ Account not found!")

    def get_balance(self, acc_no):
        account = self.accounts.get(acc_no)
        if account:
            print(f"💰 Current Balance for Account {acc_no}: {account.balance}")
        else:
            print("⚠️ Account not found!")

    def get_account_details(self, acc_no):
        account = self.accounts.get(acc_no)
        if account:
            account.get_account_details()
        else:
            print("⚠️ Account not found!")
