# dao/bank_repository_impl.py (FULL VERSION with all functions working)

from service.ibank_repository import IBankRepository
from util.db_property_util import DBPropertyUtil
from util.db_conn_util import DBConnUtil

from entity.customer import Customer
from entity.account import SavingsAccount, CurrentAccount, ZeroBalanceAccount
from entity.transaction import Transaction

from exception.custom_exceptions import (
    DatabaseOperationException,
    InvalidAccountException,
    InsufficientFundException,
    OverDraftLimitExcededException,
    DatabaseConnectionException,
    BankingException # <--- This one needs to be imported
)
import pyodbc
from datetime import datetime

class BankRepositoryImpl(IBankRepository):
    def __init__(self):
        try:
            self.db_properties = DBPropertyUtil.getConnectionString()
        except DatabaseConnectionException as e:
            print(f"Repository Initialization Error: Could not load database properties - {e}")
            raise e

    def get_db_connection(self):
        try:
            return DBConnUtil.getDBConnection()
        except DatabaseConnectionException as e:
            raise e

    def create_customer(self, customer: Customer) -> int:
        conn = None
        try:
            print(
                f"🛠️ Attempting to insert customer: {customer.customer_id} - {customer.first_name} {customer.last_name}")
            conn = self.get_db_connection()
            cursor = conn.cursor()

            sql = """
                INSERT INTO customers (customer_id, first_name, last_name, dob, email, phone_number, address)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """
            dob = datetime(2000, 1, 1)  # default dob

            cursor.execute(sql, (
                customer.customer_id,
                customer.first_name,
                customer.last_name,
                dob,
                customer.email,
                customer.phone,
                customer.address
            ))

            conn.commit()
            print(f"✅ Customer {customer.customer_id} inserted successfully into DB.")
            return customer.customer_id
        except Exception as e:
            if conn:
                conn.rollback()
            print(f"❌ Failed to insert customer: {e}")
            raise DatabaseOperationException(f"Failed to create customer: {e}")
        finally:
            if conn:
                DBConnUtil.close_db_connection(conn)

    def create_account(self, account_id: int, customer: Customer, acc_type: str, balance: float) -> int:
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            sql = """
                INSERT INTO accounts (account_id, customer_id, account_type, balance)
                VALUES (?, ?, ?, ?);
                -- SCOPE_IDENTITY() is not needed here because account_id is provided
            """
            # Include account_id along with other parameters
            cursor.execute(sql, (account_id, customer.customer_id, acc_type, balance))
            conn.commit()
            # Return the account_id that was successfully inserted
            return account_id
        except pyodbc.Error as e:
            if conn:
                conn.rollback()
            # Re-raise as a custom exception for database operations
            raise DatabaseOperationException(f"Failed to create account in database: {e}") from e
        except Exception as e:
            if conn:
                conn.rollback()
            raise BankingException(f"An unexpected error occurred during account creation: {e}") from e
        finally:
            if conn:
                DBConnUtil.close_db_connection(conn)
    def get_account_balance(self, account_id: int) -> float:
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT balance FROM accounts WHERE account_id = ?", (account_id,))
            row = cursor.fetchone()
            if row:
                return float(row[0])
            raise InvalidAccountException(account_id)
        except Exception as e:
            raise DatabaseOperationException(f"Failed to get balance for account {account_id}.") from e
        finally:
            DBConnUtil.close_db_connection(conn)

    def deposit(self, account_id: int, amount: float) -> float:
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE accounts SET balance = balance + ? WHERE account_id = ?", (amount, account_id))
            if cursor.rowcount == 0:
                raise InvalidAccountException(account_id)
            conn.commit()
            return self.get_account_balance(account_id)
        except Exception as e:
            if conn:
                conn.rollback()
            raise DatabaseOperationException(f"Failed to deposit into account {account_id}.") from e
        finally:
            DBConnUtil.close_db_connection(conn)

    def withdraw(self, account_id: int, amount: float) -> float:
        conn = None
        try:
            balance = self.get_account_balance(account_id)
            if balance < amount:
                raise InsufficientFundException(account_id, amount)
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE accounts SET balance = balance - ? WHERE account_id = ?", (amount, account_id))
            if cursor.rowcount == 0:
                raise InvalidAccountException(account_id)
            conn.commit()
            return self.get_account_balance(account_id)
        except Exception as e:
            if conn:
                conn.rollback()
            raise DatabaseOperationException(f"Failed to withdraw from account {account_id}.") from e
        finally:
            DBConnUtil.close_db_connection(conn)

    def transfer(self, from_acc: int, to_acc: int, amount: float):
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            # Check balance
            if self.get_account_balance(from_acc) < amount:
                raise InsufficientFundException(from_acc, amount)
            cursor.execute("UPDATE accounts SET balance = balance - ? WHERE account_id = ?", (amount, from_acc))
            cursor.execute("UPDATE accounts SET balance = balance + ? WHERE account_id = ?", (amount, to_acc))
            conn.commit()
        except Exception as e:
            if conn:
                conn.rollback()
            raise DatabaseOperationException(f"Failed to transfer from account {from_acc} to {to_acc}.") from e
        finally:
            DBConnUtil.close_db_connection(conn)

    def get_account_details(self, account_id: int):
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM accounts WHERE account_id = ?", (account_id,))
            return cursor.fetchone()
        except Exception as e:
            raise DatabaseOperationException(f"Failed to get account details for {account_id}.") from e
        finally:
            DBConnUtil.close_db_connection(conn)

    def list_accounts(self):
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM accounts")
            return cursor.fetchall()
        except Exception as e:
            raise DatabaseOperationException("Failed to list accounts.") from e
        finally:
            DBConnUtil.close_db_connection(conn)

    def calculate_interest(self):
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE accounts SET balance = balance + (balance * 0.045) WHERE account_type = 'Savings'")
            conn.commit()
        except Exception as e:
            if conn:
                conn.rollback()
            raise DatabaseOperationException("Failed to calculate interest.") from e
        finally:
            DBConnUtil.close_db_connection(conn)

    def get_transactions_for_account(self, acc_no: int, from_date: str, to_date: str):
        conn = None
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            query = """
                SELECT * FROM transactions
                WHERE account_id = ? AND transaction_date BETWEEN ? AND ?
            """
            cursor.execute(query, (acc_no, from_date, to_date))
            return cursor.fetchall()
        except Exception as e:
            raise DatabaseOperationException("Failed to retrieve transactions.") from e
        finally:
            DBConnUtil.close_db_connection(conn)
