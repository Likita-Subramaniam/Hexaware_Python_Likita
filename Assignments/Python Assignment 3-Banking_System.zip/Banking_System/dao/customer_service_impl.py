# dao/customer_service_impl.py (Updated for Exceptions)

from service.icustomer_service_provider import ICustomerServiceProvider
from exception.custom_exceptions import InsufficientFundException, InvalidAccountException, OverDraftLimitExcededException

class CustomerServiceProviderImpl(ICustomerServiceProvider):
    def __init__(self):
        # This dictionary will be replaced by interaction with the repository layer later
        self.accounts = {}

    def get_account_balance(self, acc_no):
        acc = self.accounts.get(acc_no)
        if acc:
            return acc.balance
        # Raise custom exception instead of ValueError
        raise InvalidAccountException(acc_no)

    def deposit(self, acc_no, amount):
        acc = self.accounts.get(acc_no)
        if acc:
            if amount <= 0:
                 # You might want another exception for invalid amount
                 raise ValueError("Deposit amount must be positive.")
            acc.balance += amount
            return acc.balance
        # Raise custom exception instead of ValueError
        raise InvalidAccountException(acc_no)

    def withdraw(self, acc_no, amount):
        acc = self.accounts.get(acc_no)
        if not acc:
            # Raise custom exception instead of ValueError
            raise InvalidAccountException(acc_no)

        if amount <= 0:
            # You might want another exception for invalid amount
            raise ValueError("Withdrawal amount must be positive.")

        if acc.acc_type == "Savings":
            # Check minimum balance rule
            if acc.balance - amount < 500:
                # Raise custom exception instead of generic Exception
                raise InsufficientFundException(acc_no, acc.balance, amount, "Withdrawal violates minimum balance rule")
        elif acc.acc_type == "Current":
            # Check overdraft limit
            # Assuming overdraft_limit is a positive value representing the allowed negative balance
            if acc.balance - amount < -acc.overdraft_limit:
                 # Raise custom exception instead of generic Exception
                 raise OverDraftLimitExcededException(acc_no, acc.balance, acc.overdraft_limit, amount)
        elif acc.acc_type == "ZeroBalance":
            # Check if balance goes below zero
            if acc.balance < amount:
                # Raise custom exception instead of generic Exception
                raise InsufficientFundException(acc_no, acc.balance, amount)

        acc.balance -= amount
        return acc.balance

    def transfer(self, from_acc_no, to_acc_no, amount):
        if amount <= 0:
            # You might want another exception for invalid amount
            raise ValueError("Transfer amount must be positive.")

        # Withdraw from the source account - this will raise exceptions if invalid or insufficient funds
        self.withdraw(from_acc_no, amount)
        # Deposit to the destination account - this will raise exception if invalid account
        self.deposit(to_acc_no, amount)
        # Note: In a real transaction, you'd need to handle the case where deposit fails after withdrawal (rollback)
        # This is more complex and often handled at the database transaction level.

    def get_account_details(self, acc_no):
        acc = self.accounts.get(acc_no)
        if not acc:
            # Raise custom exception instead of ValueError
            raise InvalidAccountException(acc_no)
        return acc

