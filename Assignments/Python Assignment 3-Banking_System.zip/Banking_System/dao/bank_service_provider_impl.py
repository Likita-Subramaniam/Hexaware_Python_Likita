# dao/bank_service_provider_impl.py (Updated to work with updated DBConnUtil)

from service.ibank_service_provider import IBankServiceProvider
from service.ibank_repository import IBankRepository
from dao.bank_repository_impl import BankRepositoryImpl

from entity.customer import Customer
from entity.account import Account
from entity.transaction import Transaction

from exception.custom_exceptions import (
    InsufficientFundException,
    InvalidAccountException,
    OverDraftLimitExcededException,
    DatabaseOperationException,
    DatabaseConnectionException,
    BankingException
)
import sys
import random
class BankServiceProviderImpl(IBankServiceProvider):
    def __init__(self):
        try:
            self.bank_repo: IBankRepository = BankRepositoryImpl()
        except DatabaseConnectionException as e:
            print(f"Service Layer Initialization Error: Could not initialize repository - {e}")
            sys.exit("Application failed to start due to database connection issues.")

        self.branch_name = "HMBank Main"
        self.branch_address = "Chennai"

    import random
    from datetime import datetime

    def create_account(self, customer: Customer, acc_type: str, balance: float) -> int:
        try:
            account_id = random.randint(1001, 9999)
            customer_id = random.randint(11, 999)
            customer.customer_id = customer_id

            print(f"📦 Creating customer with ID: {customer.customer_id}")
            self.bank_repo.create_customer(customer)  # ✅ INSERT INTO CUSTOMERS TABLE
            print(f"✅ Customer {customer.customer_id} inserted into DB successfully.")

            return self.bank_repo.create_account(account_id, customer, acc_type, balance)
        except Exception as e:
            print(f"Service Layer Error: Failed to create account - {e}")
            raise

    def list_accounts(self) -> list[Account]:
        try:
            return self.bank_repo.list_accounts()
        except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
            print(f"Service Layer Error: Failed to list accounts - {e}")
            raise e

    def calculate_interest(self):
        try:
            self.bank_repo.calculate_interest()
        except (DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
            print(f"Service Layer Error: Failed to calculate interest - {e}")
            raise e

    def get_account_balance(self, acc_no: int) -> float:
        try:
            return self.bank_repo.get_account_balance(acc_no)
        except (InvalidAccountException, DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
            print(f"Service Layer Error: Failed to get account balance - {e}")
            raise e

    def deposit(self, acc_no: int, amount: float) -> float:
        try:
            if amount <= 0:
                raise ValueError("Deposit amount must be positive.")
            return self.bank_repo.deposit(acc_no, amount)
        except (InvalidAccountException, DatabaseOperationException, DatabaseConnectionException, BankingException, ValueError) as e:
            print(f"Service Layer Error: Failed to deposit - {e}")
            raise e

    def withdraw(self, acc_no: int, amount: float) -> float:
        try:
            if amount <= 0:
                raise ValueError("Withdrawal amount must be positive.")
            return self.bank_repo.withdraw(acc_no, amount)
        except (InvalidAccountException, InsufficientFundException, OverDraftLimitExcededException, DatabaseOperationException, DatabaseConnectionException, BankingException, ValueError) as e:
            print(f"Service Layer Error: Failed to withdraw - {e}")
            raise e

    def transfer(self, from_acc_no: int, to_acc_no: int, amount: float):
        try:
            if amount <= 0:
                raise ValueError("Transfer amount must be positive.")
            if from_acc_no == to_acc_no:
                raise ValueError("Cannot transfer to the same account.")
            self.bank_repo.transfer(from_acc_no, to_acc_no, amount)
        except (InvalidAccountException, InsufficientFundException, OverDraftLimitExcededException, DatabaseOperationException, DatabaseConnectionException, BankingException, ValueError) as e:
            print(f"Service Layer Error: Failed to transfer - {e}")
            raise e

    def get_account_details(self, acc_no: int) -> Account:
        try:
            return self.bank_repo.get_account_details(acc_no)
        except (InvalidAccountException, DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
            print(f"Service Layer Error: Failed to get account details - {e}")
            raise e

    def get_transactions_for_account(self, acc_no: int, from_date: str, to_date: str) -> list[Transaction]:
        try:
            return self.bank_repo.get_transactions_for_account(acc_no, from_date, to_date)
        except (InvalidAccountException, DatabaseOperationException, DatabaseConnectionException, BankingException) as e:
            print(f"Service Layer Error: Failed to get transactions - {e}")
            raise e
