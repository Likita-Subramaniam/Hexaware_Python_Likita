# exception/custom_exceptions.py

class BankingException(Exception):
    """Base class for custom banking exceptions."""
    pass

class InsufficientFundException(BankingException):
    """Exception raised for insufficient funds during withdrawal or transfer."""
    def __init__(self, account_number, current_balance, amount_attempted, message="Insufficient funds"):
        self.account_number = account_number
        self.current_balance = current_balance
        self.amount_attempted = amount_attempted
        self.message = f"{message}: Account {account_number} has {current_balance}, attempted to withdraw/transfer {amount_attempted}."
        super().__init__(self.message)

class InvalidAccountException(BankingException):
    """Exception raised for operations on an invalid or non-existent account."""
    def __init__(self, account_number, message="Invalid account number"):
        self.account_number = account_number
        self.message = f"{message}: Account {account_number} not found."
        super().__init__(self.message)

class OverDraftLimitExcededException(BankingException):
    """Exception raised when an overdraft limit is exceeded for a current account."""
    def __init__(self, account_number, current_balance, overdraft_limit, amount_attempted, message="Overdraft limit exceeded"):
        self.account_number = account_number
        self.current_balance = current_balance
        self.overdraft_limit = overdraft_limit
        self.amount_attempted = amount_attempted
        self.message = f"{message}: Account {account_number} has {current_balance}, overdraft limit is {overdraft_limit}, attempted to withdraw {amount_attempted}."
        super().__init__(self.message)

# You might also want a generic DB exception, though SQLException is mentioned for Java/C#,
# we can use a custom one for Python or handle database-specific exceptions.
class DatabaseConnectionException(BankingException):
    """Exception raised for database connection errors."""
    def __init__(self, message="Database connection failed"):
        self.message = message
        super().__init__(self.message)

class DatabaseOperationException(BankingException):
    """Exception raised for errors during database operations."""
    def __init__(self, message="Database operation failed"):
        self.message = message
        super().__init__(self.message)
