# service/ibank_repository.py

from abc import ABC, abstractmethod
from entity.customer import Customer
from entity.account import Account # Assuming Account is the base class
from entity.transaction import Transaction # Import the Transaction entity

class IBankRepository(ABC):
    """Abstract base class for the Bank Repository."""

    @abstractmethod
    def create_customer(self, customer: Customer) -> int:
        """Creates a new customer in the database and returns the customer ID."""
        pass

    @abstractmethod
    def create_account(self, customer: Customer, acc_type: str, balance: float) -> int:
        """Creates a new account in the database and returns the account number."""
        pass

    @abstractmethod
    def list_accounts(self) -> list[Account]:
        """Retrieves all accounts from the database."""
        pass

    @abstractmethod
    def get_account_balance(self, account_number: int) -> float:
        """Retrieves the balance of a specific account from the database."""
        pass

    @abstractmethod
    def deposit(self, account_number: int, amount: float) -> float:
        """Deposits amount into an account in the database and returns the new balance."""
        pass

    @abstractmethod
    def withdraw(self, account_number: int, amount: float) -> float:
        """Withdraws amount from an account in the database and returns the new balance."""
        pass

    @abstractmethod
    def transfer(self, from_account_number: int, to_account_number: int, amount: float):
        """Transfers amount between two accounts in the database."""
        pass

    @abstractmethod
    def get_account_details(self, account_number: int) -> Account:
        """Retrieves details of a specific account from the database."""
        pass

    @abstractmethod
    def get_transactions_for_account(self, account_number: int, from_date: str, to_date: str) -> list[Transaction]:
        """Retrieves transactions for a specific account within a date range from the database."""
        pass

    @abstractmethod
    def calculate_interest(self):
        """Calculates and applies interest to savings accounts in the database."""
        pass

    # You might need methods for customer related DB operations as well
    # @abstractmethod
    # def create_customer(self, customer: Customer) -> int:
    #     """Creates a new customer in the database and returns the customer ID."""
    #     pass

    # @abstractmethod
    # def get_customer_by_id(self, customer_id: int) -> Customer:
    #     """Retrieves a customer by ID from the database."""
    #     pass

    # @abstractmethod
    # def get_customer_by_account_number(self, account_number: int) -> Customer:
    #     """Retrieves the customer associated with an account from the database."""
    #     pass

