# entity/transaction.py

from datetime import datetime # Import datetime for handling dates

class Transaction:
    def __init__(self, transaction_id: int, account_id: int, transaction_type: str, amount: float, transaction_date):
        self.transaction_id = transaction_id
        self.account_id = account_id
        self.transaction_type = transaction_type
        self.amount = amount
        # Store transaction_date, pyodbc might return datetime objects
        self.transaction_date = transaction_date

    def __str__(self):
        # Format date nicely if it's a datetime object
        date_str = self.transaction_date.strftime('%Y-%m-%d %H:%M:%S') if isinstance(self.transaction_date, datetime) else str(self.transaction_date)
        return (f"Transaction ID: {self.transaction_id}, Account ID: {self.account_id}, "
                f"Type: {self.transaction_type}, Amount: {self.amount:.2f}, Date: {date_str}")

    def __repr__(self):
        return self.__str__()

