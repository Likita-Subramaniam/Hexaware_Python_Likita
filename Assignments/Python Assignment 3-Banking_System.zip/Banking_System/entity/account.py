class Account:
    last_acc_no = 1000  # static variable

    def __init__(self, acc_type, balance, customer):
        Account.last_acc_no += 1
        self.acc_no = Account.last_acc_no
        self.acc_type = acc_type
        self.balance = balance
        self.customer = customer

    def __str__(self):
        return f"Account No: {self.acc_no}, Type: {self.acc_type}, Balance: {self.balance}"

class SavingsAccount(Account):
    def __init__(self, balance, customer):
        super().__init__("Savings", balance if balance >= 500 else 500, customer)
        self.interest_rate = 0.045

class CurrentAccount(Account):
    def __init__(self, balance, customer):
        super().__init__("Current", balance, customer)
        self.overdraft_limit = 1000

class ZeroBalanceAccount(Account):
    def __init__(self, customer):
        super().__init__("ZeroBalance", 0, customer)
