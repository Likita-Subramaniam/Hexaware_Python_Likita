from util.db_conn_util import DBConnection
from dao.CourierServiceDb import CourierServiceDb
from util.extra_util import validate_customer_info, generate_password, find_similar_address

def list_all_customers():
    conn = DBConnection.getConnection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM [User]")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

def track_courier():
    tracking_number = input("Enter tracking number: ")
    status = CourierServiceDb.get_order_status(tracking_number)
    print("Courier Status:", status)

def create_user():
    name = input("Enter name: ")
    email = input("Enter email: ")
    password = generate_password() # Consider letting the user input or confirm a password
    contact = input("Enter contact number: ")
    address = input("Enter address: ")

    conn = DBConnection.getConnection()
    cursor = conn.cursor()

    try:
        # Find the maximum existing UserID and increment it
        cursor.execute("SELECT MAX(UserID) FROM [User]")
        max_user_id = cursor.fetchone()[0]
        if max_user_id is None:
            next_user_id = 1 # Start with 1 if no users exist
        else:
            next_user_id = max_user_id + 1

        # Insert the new user with the generated UserID
        cursor.execute("INSERT INTO [User] (UserID, Name, Email, Password, ContactNumber, Address) VALUES (?, ?, ?, ?, ?, ?)",
                       (next_user_id, name, email, password, contact, address))

        conn.commit()
        print("User created successfully!")
        print(f"Generated Password: {password}") # Be cautious about displaying passwords in a real system
    except Exception as e:
        print("Error creating user:", e) # More specific error message

        # The connection is managed by DBConnection, so you might not close it here depending on your design
        # if conn:
        #     conn.close()
def validate_info():
    data = input("Enter the data to validate: ")
    detail = input("Is it 'name', 'address', or 'phone number'? ")
    valid = validate_customer_info(data, detail)
    print("Validation Result:", "✅ Valid" if valid else "❌ Invalid")

def list_all_couriers():
    conn = DBConnection.getConnection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Courier")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

def menu():
    while True:
        print("\n======= Courier Management System =======")
        print("1. List All Customers")
        print("2. Track Courier")
        print("3. Create User")
        print("4. Validate Customer Info")
        print("5. Generate Password")
        print("6. Find Similar Address")
        print("7. List All Couriers")
        print("8. Exit")
        choice = input("Enter your choice (1-8): ")

        if choice == '1':
            list_all_customers()
        elif choice == '2':
            track_courier()
        elif choice == '3':
            create_user()
        elif choice == '4':
            validate_info()
        elif choice == '5':
            print("Generated Password:", generate_password())
        elif choice == '6':
            addr = input("Enter part of address: ")
            find_similar_address(addr)
        elif choice == '7':
            list_all_couriers()
        elif choice == '8':
            print("Exiting system... Goodbye!")
            break
        else:
            print("Invalid choice! Please enter a number between 1 and 8.")

if __name__ == "__main__":
    menu()
