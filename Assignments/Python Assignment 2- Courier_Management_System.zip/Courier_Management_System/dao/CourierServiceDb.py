import pyodbc
from util.db_conn_util import DBConnection

class CourierServiceDb:
    connection = DBConnection.getConnection()

    @staticmethod
    def add_new_order(courier_obj):
        try:
            cursor = CourierServiceDb.connection.cursor()
            query = """INSERT INTO Courier (senderName, senderAddress, receiverName, receiverAddress, 
                    weight, status, trackingNumber, deliveryDate, userId) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"""
            values = (courier_obj.get_senderName(), courier_obj.get_senderAddress(), courier_obj.get_receiverName(),
                      courier_obj.get_receiverAddress(), courier_obj.get_weight(), courier_obj.get_status(),
                      courier_obj.get_trackingNumber(), courier_obj.get_deliveryDate(), courier_obj.get_userID())
            cursor.execute(query, values)
            CourierServiceDb.connection.commit()
            print("New order added successfully.")
        except Exception as e:
            print(f"Error: {e}")

    @staticmethod
    def update_order_status(tracking_number, status):
        try:
            cursor = CourierServiceDb.connection.cursor()
            query = """UPDATE Courier SET status = ? WHERE trackingNumber = ?"""
            values = (status, tracking_number)
            cursor.execute(query, values)
            CourierServiceDb.connection.commit()
            print("Order status updated successfully.")
        except Exception as e:
            print(f"Error: {e}")

    @staticmethod
    def get_order_status(tracking_number):
        try:
            cursor = CourierServiceDb.connection.cursor()
            query = """SELECT status FROM Courier WHERE trackingNumber = ?"""
            cursor.execute(query, (tracking_number,))
            result = cursor.fetchone()
            if result:
                return result[0]  # Return the status
            else:
                return "Tracking number not found."
        except Exception as e:
            print(f"Error: {e}")

    @staticmethod
    def get_delivery_history(user_id):
        try:
            cursor = CourierServiceDb.connection.cursor()
            query = """SELECT * FROM Courier WHERE userId = ?"""
            cursor.execute(query, (user_id,))
            result = cursor.fetchall()
            return result  # Return all orders for the user
        except Exception as e:
            print(f"Error: {e}")
