# dao/CourierUserServiceImpl.py (or wherever the service methods are implemented)

from exception.TrackingNumberNotFoundException import TrackingNumberNotFoundException
# dao/CourierUserServiceImpl.py

from dao.ICourierUserService import ICourierUserService
from entity.courier_company import CourierCompany


class CourierUserServiceImpl(ICourierUserService):
    def __init__(self):
        self.company_obj = CourierCompany()  # Instance of CourierCompany class

    def placeOrder(self, courier_obj):
        # Add courier order to the company
        self.company_obj.add_courier(courier_obj)
        return courier_obj.tracking_number  # Return the tracking number

    def getOrderStatus(self, tracking_number):
        # Retrieve the status of a courier order using tracking number
        for courier in self.company_obj.get_couriers():
            if courier.tracking_number == tracking_number:
                return courier.status
        raise TrackingNumberNotFoundException(f"Tracking number {tracking_number} not found.")

    def cancelOrder(self, tracking_number):
        # Cancel the courier order
        for courier in self.company_obj.get_couriers():
            if courier.tracking_number == tracking_number:
                self.company_obj.get_couriers().remove(courier)
                return True
        return False

    def getAssignedOrder(self, courier_staff_id):
        # Get all orders assigned to a specific courier staff member
        assigned_orders = []
        for courier in self.company_obj.get_couriers():
            if courier.employee_id == courier_staff_id:
                assigned_orders.append(courier)
        return assigned_orders
