# dao/CourierAdminServiceCollectionImpl.py

from dao.CourierUserServiceCollectionImpl import CourierUserServiceCollectionImpl
from dao.ICourierAdminService import ICourierAdminService
from entity.employee import Employee

class CourierAdminServiceCollectionImpl(CourierUserServiceCollectionImpl, ICourierAdminService):
    def addCourierStaff(self, employee_obj):
        # Add new courier staff member to the company using collection-based approach
        self.company_obj.add_employee(employee_obj)
        return employee_obj.employee_id  # Return the employee ID
