# dao/CourierUserServiceCollectionImpl.py

from entity.CourierCompanyCollection import CourierCompanyCollection
from dao.ICourierUserService import ICourierUserService
from exception.TrackingNumberNotFoundException import TrackingNumberNotFoundException


class CourierUserServiceCollectionImpl(ICourierUserService):
    def __init__(self):
        self.company_obj = CourierCompanyCollection()  # Create instance of CourierCompanyCollection

    def placeOrder(self, courier_obj):
        # Add new courier order to the collection
        self.company_obj.add_courier(courier_obj)
        return courier_obj.tracking_number  # Return the tracking number of the placed order

    def getOrderStatus(self, tracking_number):
        # Get courier details by tracking number
        for courier in self.company_obj.get_couriers():
            if courier.tracking_number == tracking_number:
                return courier.status
        raise TrackingNumberNotFoundException(f"Tracking number {tracking_number} not found.")

    def cancelOrder(self, tracking_number):
        # Cancel the order if tracking number is found
        for courier in self.company_obj.get_couriers():
            if courier.tracking_number == tracking_number:
                self.company_obj.get_couriers().remove(courier)
                return True
        return False

    def getAssignedOrder(self, courier_staff_id):
        # Get all orders assigned to a specific courier staff member
        assigned_orders = []
        for courier in self.company_obj.get_couriers():
            if courier.employee_id == courier_staff_id:
                assigned_orders.append(courier)
        return assigned_orders
