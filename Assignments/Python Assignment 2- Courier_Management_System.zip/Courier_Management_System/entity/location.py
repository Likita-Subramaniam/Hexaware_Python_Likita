class Location:
    def __init__(self, locationID, locationName, address):
        self.__locationID = locationID
        self.__locationName = locationName
        self.__address = address

    # Getters and Setters
    def get_locationID(self):
        return self.__locationID

    def set_locationID(self, locationID):
        self.__locationID = locationID

    # toString method (equivalent in Python)
    def __str__(self):
        return f"Location ID: {self.__locationID}, Name: {self.__locationName}, Address: {self.__address}"
