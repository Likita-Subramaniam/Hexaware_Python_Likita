# entity/CourierCompanyCollection.py

class CourierCompanyCollection:
    def __init__(self):
        self.courier_details = []  # List to hold Courier objects
        self.employee_details = []  # List to hold Employee objects
        self.location_details = []  # List to hold Location objects

    # Method to add a new Courier object to the collection
    def add_courier(self, courier):
        self.courier_details.append(courier)

    # Method to add a new Employee object to the collection
    def add_employee(self, employee):
        self.employee_details.append(employee)

    # Method to add a new Location object to the collection
    def add_location(self, location):
        self.location_details.append(location)

    # Optionally, you can create methods to remove or fetch items from the collection
    def get_couriers(self):
        return self.courier_details

    def get_employees(self):
        return self.employee_details

    def get_locations(self):
        return self.location_details
