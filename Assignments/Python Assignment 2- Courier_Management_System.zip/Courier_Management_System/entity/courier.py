class Courier:
    tracking_number_counter = 1000  # static variable for tracking number

    def __init__(self, courierID, senderName, senderAddress, receiverName, receiverAddress, weight, status, deliveryDate, userID):
        self.__courierID = courierID
        self.__senderName = senderName
        self.__senderAddress = senderAddress
        self.__receiverName = receiverName
        self.__receiverAddress = receiverAddress
        self.__weight = weight
        self.__status = status
        self.__trackingNumber = Courier.tracking_number_counter
        Courier.tracking_number_counter += 1
        self.__deliveryDate = deliveryDate
        self.__userID = userID

    # Getters
    def get_courierID(self):
        return self.__courierID

    def get_senderName(self):
        return self.__senderName

    def get_senderAddress(self):
        return self.__senderAddress

    def get_receiverName(self):
        return self.__receiverName

    def get_receiverAddress(self):
        return self.__receiverAddress

    def get_weight(self):
        return self.__weight

    def get_status(self):
        return self.__status

    def get_trackingNumber(self):
        return self.__trackingNumber

    def get_deliveryDate(self):
        return self.__deliveryDate

    def get_userID(self):
        return self.__userID

    # Setters
    def set_courierID(self, courierID):
        self.__courierID = courierID

    def set_senderName(self, senderName):
        self.__senderName = senderName

    def set_senderAddress(self, senderAddress):
        self.__senderAddress = senderAddress

    def set_receiverName(self, receiverName):
        self.__receiverName = receiverName

    def set_receiverAddress(self, receiverAddress):
        self.__receiverAddress = receiverAddress

    def set_weight(self, weight):
        self.__weight = weight

    def set_status(self, status):
        self.__status = status

    def set_deliveryDate(self, deliveryDate):
        self.__deliveryDate = deliveryDate

    def set_userID(self, userID):
        self.__userID = userID

    # String representation
    def __str__(self):
        return f"Courier ID: {self.__courierID}, Sender: {self.__senderName}, Receiver: {self.__receiverName}, Status: {self.__status}"
