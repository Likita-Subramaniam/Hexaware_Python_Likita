class Payment:
    def __init__(self, paymentID, courierID, amount, paymentDate):
        self.__paymentID = paymentID
        self.__courierID = courierID
        self.__amount = amount
        self.__paymentDate = paymentDate

    # Getters and Setters
    def get_paymentID(self):
        return self.__paymentID

    def set_paymentID(self, paymentID):
        self.__paymentID = paymentID

    # toString method (equivalent in Python)
    def __str__(self):
        return f"Payment ID: {self.__paymentID}, Courier ID: {self.__courierID}, Amount: {self.__amount}, Date: {self.__paymentDate}"
