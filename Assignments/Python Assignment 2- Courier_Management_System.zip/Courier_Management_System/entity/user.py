class User:
    def __init__(self, userID, userName, email, password, contactNumber, address):
        self.__userID = userID
        self.__userName = userName
        self.__email = email
        self.__password = password
        self.__contactNumber = contactNumber
        self.__address = address

    # Getters and Setters
    def get_userID(self):
        return self.__userID

    def set_userID(self, userID):
        self.__userID = userID

    def get_userName(self):
        return self.__userName

    def set_userName(self, userName):
        self.__userName = userName

    def get_email(self):
        return self.__email

    def set_email(self, email):
        self.__email = email

    def get_password(self):
        return self.__password

    def set_password(self, password):
        self.__password = password

    def get_contactNumber(self):
        return self.__contactNumber

    def set_contactNumber(self, contactNumber):
        self.__contactNumber = contactNumber

    def get_address(self):
        return self.__address

    def set_address(self, address):
        self.__address = address

    # toString method (equivalent in Python)
    def __str__(self):
        return f"User ID: {self.__userID}, Name: {self.__userName}, Email: {self.__email}, Address: {self.__address}"
