import random
import string
import re
from util.db_conn_util import DBConnection

# Password Generator
def generate_password(length=10):
    characters = string.ascii_letters + string.digits + "!@#$%^&*()"
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

# Validate customer information
def validate_customer_info(data, detail):
    if detail.lower() == "name":
        return data.isalpha() and data.istitle()
    elif detail.lower() == "address":
        return bool(re.match(r'^[\w\s,.-]+$', data))
    elif detail.lower() == "phone number":
        return bool(re.match(r'^\d{10}$', data))
    else:
        return False

# Find similar addresses
# Find similar addresses
def find_similar_address(address_input):
    conn = DBConnection.getConnection()
    cursor = None # Initialize cursor to None
    try:
        cursor = conn.cursor() # Assign cursor here
        # Cast Address to VARCHAR(MAX) to use DISTINCT and query
        query = "SELECT DISTINCT CAST(Address AS VARCHAR(MAX)) FROM [User] WHERE Address LIKE ?"
        cursor.execute(query, (f"%{address_input}%",))
        results = cursor.fetchall()
        if results:
            print("\nSimilar Addresses Found:")
            for row in results:
                print("-", row[0])
        else:
            print("No similar addresses found.")
    except Exception as e:
        print("Error finding similar addresses:", e) # More specific error message

        # The connection is managed by DBConnection, so you might not close it here
