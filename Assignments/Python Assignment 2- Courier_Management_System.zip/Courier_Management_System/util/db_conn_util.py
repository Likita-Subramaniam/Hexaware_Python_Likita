# db_conn_util.py
import pyodbc
from util.db_property_util import get_db_properties  # Import the function

# DB Connection class to manage the connection
class DBConnection:
    connection = None

    @staticmethod
    def getConnection():
        if DBConnection.connection is None:
            try:
                # Get DB properties directly from db_property_util
                db_properties = get_db_properties()

                # Build connection string based on user authentication
                if db_properties['user'] and db_properties['password']:
                    # SQL Authentication
                    connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={db_properties["server"]};DATABASE={db_properties["dbname"]};UID={db_properties["user"]};PWD={db_properties["password"]}'
                else:
                    # Windows Authentication (no username, no password)
                    connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={db_properties["server"]};DATABASE={db_properties["dbname"]};Trusted_Connection=yes;'

                # Connect to the database
                DBConnection.connection = pyodbc.connect(connection_string)
                print("Connection successful.")
            except Exception as e:
                print(f"Error: {e}")
        return DBConnection.connection
