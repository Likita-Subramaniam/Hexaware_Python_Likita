# db_property_util.py

# A dictionary that holds database properties
def get_db_properties():
    db_properties = {
        "server": "LAPTOP-LIKITA",  # e.g., localhost or server address
        "dbname": "CMSDB",  # Your database name
        "user": "",  # Leave empty if using Windows Authentication
        "password": ""  # Leave empty if using Windows Authentication
    }
    return db_properties
