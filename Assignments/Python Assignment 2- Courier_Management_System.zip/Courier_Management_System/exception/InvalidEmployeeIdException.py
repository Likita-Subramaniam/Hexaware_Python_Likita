# exception/InvalidEmployeeIdException.py
class InvalidEmployeeIdException(Exception):
    def __init__(self, message="Invalid employee ID. Please enter a valid ID."):
        self.message = message
        super().__init__(self.message)
