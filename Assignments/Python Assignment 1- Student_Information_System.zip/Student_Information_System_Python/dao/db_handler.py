from util.db_conn_util import DBConnUtil

class DBHandler:
    def __init__(self):
        self.conn = DBConnUtil.get_connection()
        self.cursor = self.conn.cursor()

    def insert_student(self, student):
        query = """
            INSERT INTO students (student_id, first_name, last_name, date_of_birth, email, phone_number)
            VALUES (?, ?, ?, ?, ?, ?)
        """
        self.cursor.execute(query, student.student_id, student.first_name, student.last_name,
                            student.date_of_birth, student.email, student.phone_number)
        self.conn.commit()

    def insert_enrollment(self, enrollment):
        query = """
            INSERT INTO enrollments (enrollment_id, student_id, course_id, enrollment_date)
            VALUES (?, ?, ?, ?)
        """
        self.cursor.execute(query, enrollment.enrollment_id,
                            enrollment.student.student_id,
                            enrollment.course.course_id,
                            enrollment.enrollment_date)
        self.conn.commit()

    def insert_payment(self, payment):
        query = """
            INSERT INTO payments (payment_id, student_id, amount, payment_date)
            VALUES (?, ?, ?, ?)
        """
        self.cursor.execute(query, payment.payment_id,
                            payment.student.student_id,
                            payment.amount,
                            payment.payment_date)
        self.conn.commit()

    def update_course_teacher(self, course_id, teacher_id):
        query = "UPDATE courses SET teacher_id = ? WHERE course_id = ?"
        self.cursor.execute(query, teacher_id, course_id)
        self.conn.commit()

    def close_connection(self):
        self.conn.close()
