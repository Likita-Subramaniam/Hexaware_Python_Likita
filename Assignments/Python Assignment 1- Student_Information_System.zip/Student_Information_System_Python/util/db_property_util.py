class DBPropertyUtil:
    @staticmethod
    def get_connection_string(file_name):
        return "SQL Server"
