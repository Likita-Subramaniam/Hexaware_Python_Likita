import pyodbc

class DBConnUtil:
    @staticmethod
    def get_connection():
        connection = pyodbc.connect(
            'DRIVER={SQL Server};'
            'SERVER=LAPTOP-LIKITA;'
            'DATABASE=SISDB;'
            'Trusted_Connection=yes;'
        )
        return connection
